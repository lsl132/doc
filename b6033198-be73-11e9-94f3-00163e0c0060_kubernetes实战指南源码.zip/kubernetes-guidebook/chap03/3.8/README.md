````
  1. Change ssl files of etcd to yours in the deploy
  2. Change tlsConfig and addresses of etcd to yours in the manifests/prometheus/prometheus-etcd.yaml
  3. Modify the smtp and receivers configuration in the altermanager.yaml
  4. Install: ./deploy and Uninstall: ./teardown
````
