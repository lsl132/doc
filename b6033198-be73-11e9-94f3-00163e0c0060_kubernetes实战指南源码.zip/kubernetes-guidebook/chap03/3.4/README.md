````
  此yaml为openshift容器云拆分而来，用于简单部署持久化RabbitMQ Cluster
  使用方法：https://www.cnblogs.com/dukuan/p/9897443.html

````
